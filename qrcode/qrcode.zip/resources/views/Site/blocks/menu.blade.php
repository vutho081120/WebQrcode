<div class="menuFrame">
    <div class="menuTop">
        <ul class="nav">
            <li>
                <a href="{{route('site.home.homeShow')}}"> Trang chủ </a>
            </li>
        </ul>
    </div>
</div>