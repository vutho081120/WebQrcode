@extends('Site.layouts.MasterLayout')

@section('title')
    <title> Kiểm tra QRCode </title>
@endsection

@section('content')
    <div class="fail" style="width: 1240px; margin: 0 auto; padding-top: 16px;">
        <div class="alert alert-danger" role="alert">
            <h4 class="alert-heading">Cảnh báo!</h4>
            <p>Bạn đã mua phải sản phẩm giả mạo hoặc mã số sản phẩm của Quý khách đã được kích hoạt!. 
                Để biết thêm thông tin vui lòng liên hệ 0345444322 hoặc <a href="http://uniqlo.com">http://uniqlo.com</a></p>
        </div>
    </div>
@endsection
<span></span>