<div class="menuFrame">
    <div class="menuTop">
        <ul class="nav">
            <li>
                <a href="{{route('qrcode.batch.batchShow')}}"> Danh sách lô hàng </a>
            </li>
            <li>
                <a href="{{route('qrcode.product.productListShow')}}"> Danh sách sản phẩm </a>
            </li>
            {{-- <li>
                <a href="{{ route('qrcode.batch.verifyBatchShow') }}"> Xác minh lô hàng </a>
            </li>
            <li>
                <a href="{{ route('qrcode.product.verifyProductShow') }}"> Xác minh sản phẩm </a>
            </li> --}}
        </ul>
    </div>
</div>